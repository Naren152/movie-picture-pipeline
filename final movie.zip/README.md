# Movie Picture Pipeline

A fully automated CI/CD pipeline for a movie catalog web application using GitHub Actions, Amazon ECR, and Amazon EKS.

## Architecture

```
Frontend (React/TypeScript) ──► ECR ──► EKS
Backend  (Python/Flask)     ──► ECR ──► EKS
```

## Workflows

| Workflow | File | Trigger |
|---|---|---|
| Frontend CI | `.github/workflows/frontend-ci.yaml` | PR to `main` (frontend changes) |
| Frontend CD | `.github/workflows/frontend-cd.yaml` | Push to `main` (frontend changes) |
| Backend CI  | `.github/workflows/backend-ci.yaml`  | PR to `main` (backend changes) |
| Backend CD  | `.github/workflows/backend-cd.yaml`  | Push to `main` (backend changes) |

All workflows can also be triggered manually via `workflow_dispatch`.

## GitHub Secrets Required

Set the following secrets in your GitHub repository (**Settings → Secrets and variables → Actions**):

| Secret | Description |
|---|---|
| `AWS_ACCESS_KEY_ID` | AWS access key for `github-action-user` |
| `AWS_SECRET_ACCESS_KEY` | AWS secret key for `github-action-user` |
| `FRONTEND_ECR_REPO_NAME` | ECR repository name for frontend (e.g. `frontend`) |
| `BACKEND_ECR_REPO_NAME` | ECR repository name for backend (e.g. `backend`) |
| `EKS_CLUSTER_NAME` | EKS cluster name (e.g. `cluster`) |
| `REACT_APP_MOVIE_API_URL` | Backend service URL used by the React app (e.g. `http://<backend-lb-url>:5000`) |

## Local Development

### Frontend

```bash
cd starter/frontend
npm ci
REACT_APP_MOVIE_API_URL=http://localhost:5000 npm start
```

### Backend

```bash
cd starter/backend
pipenv install
pipenv run serve
```

## Infrastructure Setup (Terraform)

```bash
# Install Terraform >= 1.3.9
cd setup/terraform
terraform init
terraform apply

# Note the outputs:
# - cluster_name
# - frontend_ecr_url
# - backend_ecr_url
```

### Add GitHub Actions User to Kubernetes

```bash
aws eks update-kubeconfig --name cluster --region us-east-1
cd setup
./init.sh
```

## Teardown

```bash
cd setup/terraform
terraform destroy
```
