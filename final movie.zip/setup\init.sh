#!/bin/bash

# init.sh - Adds the github-action-user IAM user to the Kubernetes cluster
# Run this script once after setting up your EKS cluster

set -e

echo "Fetching IAM user ARN for github-action-user..."
userarn=$(aws iam get-user --user-name github-action-user --query 'User.Arn' --output text)
echo "User ARN: $userarn"

CLUSTER_NAME=${EKS_CLUSTER_NAME:-cluster}
AWS_REGION=${AWS_REGION:-us-east-1}

echo "Updating kubeconfig for cluster: $CLUSTER_NAME"
aws eks update-kubeconfig --name "$CLUSTER_NAME" --region "$AWS_REGION"

echo "Downloading AWS IAM Authenticator..."
curl -Lo aws-iam-authenticator \
  "https://github.com/kubernetes-sigs/aws-iam-authenticator/releases/download/v0.6.2/aws-iam-authenticator_0.6.2_linux_amd64"
chmod +x aws-iam-authenticator

echo "Adding IAM user to Kubernetes aws-auth ConfigMap..."
./aws-iam-authenticator add user \
  --userarn "$userarn" \
  --username github-action-role \
  --groups system:masters \
  --kubeconfig ~/.kube/config

echo "Cleaning up..."
rm -f aws-iam-authenticator

echo "Done! github-action-user has been added to the cluster."
