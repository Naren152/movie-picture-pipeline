import { render, screen } from '@testing-library/react';
import App from '../../App';

jest.mock('axios', () => ({
  get: jest.fn(() =>
    Promise.resolve({
      data: {
        movies: [
          { id: '123', title: 'Top Gun: Maverick' },
          { id: '456', title: 'Sonic the Hedgehog' },
          { id: '789', title: 'A Quiet Place' },
        ],
      },
    })
  ),
}));

test('renders Movie Picture Pipeline heading', () => {
  render(<App />);
  const heading = screen.getByText(/Movie Picture Pipeline/i);
  expect(heading).toBeInTheDocument();
});
