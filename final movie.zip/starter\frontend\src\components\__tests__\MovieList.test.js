import { render, screen } from '@testing-library/react';
import MovieList from '../MovieList';

const mockMovies = [
  { id: '123', title: 'Top Gun: Maverick' },
  { id: '456', title: 'Sonic the Hedgehog' },
  { id: '789', title: 'A Quiet Place' },
];

test('renders movie list with correct titles', () => {
  render(<MovieList movies={mockMovies} />);
  expect(screen.getByText('Top Gun: Maverick')).toBeInTheDocument();
  expect(screen.getByText('Sonic the Hedgehog')).toBeInTheDocument();
  expect(screen.getByText('A Quiet Place')).toBeInTheDocument();
});

test('renders no movies found when list is empty', () => {
  render(<MovieList movies={[]} />);
  expect(screen.getByText('No movies found.')).toBeInTheDocument();
});
