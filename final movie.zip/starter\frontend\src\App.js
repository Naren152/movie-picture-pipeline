import React, { useEffect, useState } from 'react';
import axios from 'axios';
import MovieList from './components/MovieList';

const API_URL = process.env.REACT_APP_MOVIE_API_URL || 'http://localhost:5000';

function App() {
  const [movies, setMovies] = useState([]);
  const [error, setError] = useState(null);

  useEffect(() => {
    axios
      .get(`${API_URL}/movies`)
      .then((res) => setMovies(res.data.movies))
      .catch((err) => setError(err.message));
  }, []);

  return (
    <div className="App">
      <h1>Movie Picture Pipeline</h1>
      {error && <p style={{ color: 'red' }}>Error: {error}</p>}
      <MovieList movies={movies} />
    </div>
  );
}

export default App;
