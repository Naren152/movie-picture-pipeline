import pytest
import json
from app import app


@pytest.fixture
def client():
    app.config["TESTING"] = True
    with app.test_client() as client:
        yield client


def test_movies_endpoint_returns_200(client):
    response = client.get("/movies")
    assert response.status_code == 200


def test_movies_endpoint_returns_json(client):
    response = client.get("/movies")
    assert response.content_type == "application/json"


def test_movies_endpoint_returns_valid_data(client):
    response = client.get("/movies")
    data = json.loads(response.data)
    assert "movies" in data
    assert len(data["movies"]) > 0
    for movie in data["movies"]:
        assert "id" in movie
        assert "title" in movie
